$(document).ready(function() {
$("p").css("background-color", "cyan");
});
