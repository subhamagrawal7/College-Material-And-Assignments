<?php
/*
  if(isset($_GET['x']) && !empty($_GET['x'])){
    $x=json_decode($_GET['x']);

    echo $x->name;
  }*/
?>
