myApp.controller("myController", function ($scope) {
    $scope.message = "SVNIT COllege Surat";
});
